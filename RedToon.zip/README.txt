REDTOON — EAGLERCRAFT 1.12 RESOURCE PACK (EXPANDED)

Target format: Java Minecraft 1.12 / 1.12.2 (pack_format 3).

Includes:
- Translucent red hotbar and selected-slot highlight
- Red crafting and inventory screens
- Custom red/white crosshair
- Expanded cartoon-style textures for many common blocks, ores, wood types,
  colored wool, tools, armor, food, drops, and utility items
- Unmodified game defaults remain for textures not included

Install:
1. Keep this ZIP intact.
2. In Eaglercraft 1.12, open Options > Resource Packs.
3. Open the resource-pack folder (if available) and put this ZIP inside.
4. Select RedToon and return to the game.

This pack targets the 1.12 resource-pack layout. Some Eaglercraft 1.12 builds
may have small differences in supported GUI assets.
